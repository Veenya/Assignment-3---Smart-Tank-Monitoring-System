RIVER-MONITORING-SERVICE


this server as a broker it's the intermediary between all the system components.

Communicate with Arduino using Serial Line 
Communicate with esp32 using MQTT 
Communicate with frontend dashboard using HTTP 

---

## How to run CUS

1) (MQTT broker + HTTP API)

Windows:
```bash
cd CUS\Server
.\gradlew.bat run
```

Linux/macOS:
```bash
cd CUS/Server
chmod +x gradlew
./gradlew run
```